# TODO: implement RecommendationItem («entity»)
# TODO: attribute - rank: int
# TODO: attribute - totalScore: double
# TODO: attribute - targetSubzone: Subzone
# TODO: operation + getRank(): int
# TODO: operation + getScore(): double
# TODO: operation + getSubzone(): Subzone
