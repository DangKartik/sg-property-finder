# TODO: implement Subzone («entity»)
# TODO: attribute - subzoneId: String
# TODO: attribute - name: String
# TODO: attribute - boundariesGeoJson: String
# TODO: attribute - amenities: List<AmenityInfo>
# TODO: attribute - commuteEstimates: List<CommuteEstimate>
# TODO: attribute - pricing: HousePricing
# TODO: attribute - environment: EnvironmentInfo
# TODO: operation + getId(): String
# TODO: operation + addAmenity(amenity: AmenityInfo): void
# TODO: operation + setHousePricing(pricing: HousePricing): void
# TODO: relationship: 1 Subzone has 0..* AmenityInfo, 0..* CommuteEstimate, 0..1 HousePricing, 0..1 EnvironmentInfo
