# TODO: implement HousePricing («entity»)
# TODO: attribute - medianPrice: double
# TODO: attribute - propertyType: String
# TODO: attribute - pricePerSqFt: double
# TODO: operation + getMedianPrice(): double
