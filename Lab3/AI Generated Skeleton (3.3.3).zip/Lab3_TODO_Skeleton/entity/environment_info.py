# TODO: implement EnvironmentInfo («entity»)
# TODO: attribute - airQualityIndex: int
# TODO: attribute - greenSpacePercentage: double
# TODO: attribute - averageNoiseLevelDb: double
# TODO: operation + getGreenSpace(): double
