# TODO: implement CriterionWeight («entity»)
# TODO: attribute - criterionName: String
# TODO: attribute - weightValue: double
# TODO: operation + getCriterionName(): String
# TODO: operation + getWeightValue(): double
