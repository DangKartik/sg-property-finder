# TODO: implement CommuteEstimate («entity»)
# TODO: attribute - durationMinutes: int
# TODO: attribute - transitMode: String
# TODO: attribute - distanceKm: double
# TODO: operation + getDuration(): int
# TODO: operation + getMode(): String
