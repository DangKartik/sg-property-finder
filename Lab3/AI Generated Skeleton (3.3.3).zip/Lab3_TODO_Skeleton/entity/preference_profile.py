# TODO: implement PreferenceProfile («entity»)
# TODO: attribute - profileId: String
# TODO: attribute - profileName: String
# TODO: attribute - criteriaWeights: List<CriterionWeight>
# TODO: operation + getWeightForCriterion(criterion: String): double
# TODO: operation + updateWeight(criterion: String, weight: double): void
# TODO: relationship: 1 PreferenceProfile contains 1..* CriterionWeight
