# TODO: implement PdfReport («entity»)
# TODO: attribute - reportId: String
# TODO: attribute - contentBytes: byte[]
# TODO: attribute - createdAt: Date
# TODO: operation + getFileStream(): InputStream
