# TODO: implement AmenityInfo («entity»)
# TODO: attribute - amenityId: String
# TODO: attribute - category: String
# TODO: attribute - name: String
# TODO: attribute - location: Coordinates
# TODO: operation + getCategory(): String
# TODO: operation + getName(): String
