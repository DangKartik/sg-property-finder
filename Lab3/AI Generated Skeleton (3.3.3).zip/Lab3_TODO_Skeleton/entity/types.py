# TODO: define the shared types the diagram uses but never defines: Coordinates, ProfileForm, ValidationResult, RawResponse, MapData, RouteData, FactSheetData, TransitMode
