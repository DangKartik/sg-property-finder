# TODO: implement ProfileSelectorUI («boundary»)
# TODO: attribute - rankingControl: RankingControl
# TODO: operation + renderSelector(profiles: List<PreferenceProfile>): void
# TODO: operation + onSelectProfile(profileId: String): void
# TODO: relationship: uses RankingControl
