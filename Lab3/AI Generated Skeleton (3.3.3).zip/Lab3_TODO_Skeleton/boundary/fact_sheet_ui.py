# TODO: implement FactSheetUI («boundary»)
# TODO: attribute - detailsControl: NeighborhoodDetailsControl
# TODO: operation + displaySubzoneDetails(subzoneId: String): void
# TODO: relationship: uses NeighborhoodDetailsControl
