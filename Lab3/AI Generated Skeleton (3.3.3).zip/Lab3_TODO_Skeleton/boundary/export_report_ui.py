# TODO: implement ExportReportUI («boundary»)
# TODO: attribute - reportControl: ReportControl
# TODO: operation + openExportModal(): void
# TODO: operation + onConfirmExport(format: String): void
# TODO: relationship: uses ReportControl
