# TODO: implement NotificationModalUI («boundary»)
# TODO: attribute - currentMessage: String
# TODO: operation + showNotification(message: String, type: String): void
# TODO: operation + dismiss(): void
