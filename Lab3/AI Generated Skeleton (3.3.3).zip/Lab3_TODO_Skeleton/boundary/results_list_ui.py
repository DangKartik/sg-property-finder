# TODO: implement ResultsListUI («boundary»)
# TODO: attribute - rankingControl: RankingControl
# TODO: operation + renderResults(results: RecommendationSet): void
# TODO: operation + onSubzoneClick(subzoneId: String): void
# TODO: relationship: uses RankingControl
