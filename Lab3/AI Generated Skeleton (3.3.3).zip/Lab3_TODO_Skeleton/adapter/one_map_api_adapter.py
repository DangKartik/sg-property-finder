# TODO: implement OneMapApiAdapter («adapter»)
# TODO: attribute - baseUrl: String
# TODO: operation + fetchDataset(datasetId: String): String
