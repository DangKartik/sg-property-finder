# TODO: implement DataGovSgAdapter («adapter»)
# TODO: attribute - apiKey: String
# TODO: attribute - baseUrl: String
# TODO: operation + fetchRoute(start: Coordinates, end: Coordinates): String
# TODO: operation + fetchSubzonePolygons(): String
