# TODO: implement ProfileCatalog («container»)
# TODO: attribute - profiles: Map<String, PreferenceProfile>
# TODO: operation + addProfile(profile: PreferenceProfile): void
# TODO: operation + getProfile(id: String): PreferenceProfile
# TODO: operation + getAllProfiles(): List<PreferenceProfile>
# TODO: operation + deleteProfile(id: String): void
# TODO: operation + saveToIndexedDB(): void
# TODO: operation + loadFromIndexedDB(): void
# TODO: relationship: 1 ProfileCatalog contains 0..* PreferenceProfile
