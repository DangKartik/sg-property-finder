# TODO: implement SubzoneRegistry («container»)
# TODO: attribute - subzones: Map<String, Subzone>
# TODO: operation + getSubzone(id: String): Subzone
# TODO: operation + getAllSubzones(): List<Subzone>
# TODO: operation + loadSubzones(data: List<Subzone>): void
# TODO: relationship: 1 SubzoneRegistry contains 0..* Subzone
