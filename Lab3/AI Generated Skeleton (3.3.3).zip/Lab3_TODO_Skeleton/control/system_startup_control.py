# TODO: implement SystemStartupControl («control»)
# TODO: attribute - instance: SystemStartupControl (static)
# TODO: attribute - profileCatalog: ProfileCatalog
# TODO: attribute - subzoneRegistry: SubzoneRegistry
# TODO: operation + getInstance(): SystemStartupControl (static)
# TODO: operation + main(args: String[]): void
# TODO: operation + initializeSystem(): void
