# TODO: implement RetrievalControl («control»)
# TODO: attribute # dataAdapter: DataGovSgAdapter
# TODO: operation + fetchData(datasetId: String): RawResponse
# TODO: operation # parseResponse(data: RawResponse): Object {abstract}
# TODO: relationship: abstract; uses DataGovSgAdapter
