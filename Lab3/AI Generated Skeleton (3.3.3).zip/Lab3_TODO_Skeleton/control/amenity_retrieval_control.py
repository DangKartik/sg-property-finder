# TODO: implement AmenityRetrievalControl («control»)
# TODO: operation # parseResponse(data: RawResponse): List<AmenityInfo>
# TODO: operation + fetchAmenitiesForSubzone(subzoneId: String): List<AmenityInfo>
# TODO: relationship: extends RetrievalControl
