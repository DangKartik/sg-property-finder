# TODO: implement DataAvailabilityNotifier («control»)
# TODO: operation + notifyMissingData(source: String, entityId: String): void
# TODO: relationship: uses NotificationModalUI
# TODO: relationship: used by RetrievalControl and ReportControl
