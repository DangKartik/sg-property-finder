# TODO: implement ProfileControl («control»)
# TODO: attribute - profileCatalog: ProfileCatalog
# TODO: operation + createProfile(profileData: ProfileForm): boolean
# TODO: operation + updateProfile(id: String, profileData: ProfileForm): boolean
# TODO: relationship: uses ProfileCatalog
# TODO: relationship: uses InputValidationControl
