# TODO: implement RankingControl («control»)
# TODO: attribute - subzoneRegistry: SubzoneRegistry
# TODO: attribute - commuteControl: CommuteControl
# TODO: attribute - mapAdapter: OneMapApiAdapter
# TODO: operation + getSubzonePolygons(): MapData
# TODO: operation + getCommuteOverlay(start: Coordinates, dest: Coordinates): RouteData
# TODO: relationship: uses ScoringStrategy
# TODO: relationship: uses ProfileCatalog
# TODO: relationship: uses RecommendationSet
