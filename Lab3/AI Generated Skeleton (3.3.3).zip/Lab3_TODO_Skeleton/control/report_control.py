# TODO: implement ReportControl («control»)
# TODO: attribute - lastGeneratedReport: PdfReport
# TODO: operation + generatePdfReport(recommendationSet: RecommendationSet): PdfReport
# TODO: operation + exportToFile(report: PdfReport, filePath: String): boolean
# TODO: relationship: uses DataAvailabilityNotifier
