# TODO: implement NeighborhoodDetailsControl («control»)
# TODO: attribute - amenityRetrieval: RetrievalControl
# TODO: attribute - envRetrieval: RetrievalControl
# TODO: attribute - priceRetrieval: RetrievalControl
# TODO: operation + getFullFactSheet(subzoneId: String): FactSheetData
