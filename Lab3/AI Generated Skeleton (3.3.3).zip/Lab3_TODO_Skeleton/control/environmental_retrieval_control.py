# TODO: implement EnvironmentalRetrievalControl («control»)
# TODO: operation # parseResponse(data: RawResponse): List<AmenityInfo>
# TODO: operation + fetchEnvironmentForSubzone(subzoneId: String): List<AmenityInfo>
# TODO: relationship: extends RetrievalControl
