# TODO: implement CommuteControl («control»)
# TODO: attribute - apiAdapter: OneMapApiAdapter
# TODO: operation + calculateTravelTime(origin: Coordinates, dest: Coordinates, mode: TransitMode): CommuteEstimate
