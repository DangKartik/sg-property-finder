# TODO: implement MapControl («control»)
# TODO: attribute - subzoneRegistry: SubzoneRegistry
# TODO: attribute - commuteControl: CommuteControl
# TODO: attribute - mapAdapter: OneMapApiAdapter
# TODO: operation + getSubzonePolygons(): MapData
# TODO: operation + getCommuteOverlay(start: Coordinates, dest: Coordinates): RouteData
