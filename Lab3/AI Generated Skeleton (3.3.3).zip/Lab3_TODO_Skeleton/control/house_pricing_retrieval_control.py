# TODO: implement HousePricingRetrievalControl («control»)
# TODO: operation # parseResponse(data: RawResponse): List<AmenityInfo>
# TODO: operation + fetchPricingForSubzone(subzoneId: String): List<AmenityInfo>
# TODO: relationship: extends RetrievalControl
