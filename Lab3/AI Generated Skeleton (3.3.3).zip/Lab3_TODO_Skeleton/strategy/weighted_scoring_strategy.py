# TODO: implement WeightedScoringStrategy («strategy»)
# TODO: attribute - weightsMap: Map<String, Double>
# TODO: operation + calculateScore(subzone: Subzone, profile: PreferenceProfile): double
# TODO: relationship: implements ScoringStrategy
