# TODO: implement ScoringStrategy («strategy»)
# TODO: operation + calculateScore(subzone: Subzone, profile: PreferenceProfile): double
# TODO: relationship: interface
